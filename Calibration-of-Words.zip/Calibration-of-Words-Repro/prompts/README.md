# prompts/

Every prompt is stored as plain JSON so the exact wording used in the paper can
be diffed. Each entry has an `id` (referenced by the manifests and by every
output filename), a `text` template, and the `target_words` to be weighted.

| File | Entries | Used by | Notes |
|------|---------|---------|-------|
| `main_prompts.json` | 60 | `main` | 6 categories x 10: person, animal, object, scene, material, abstract |
| `two_word_prompts.json` | 15 | `two_word` | two target words per prompt, both weighted at the same level |
| `generalization_prompts.json` | 10 | `generalization` | held out of the calibration fit |
| `calibration_prompts.json` | 10 words x 4 operations | `calibration` | the 12-rater reference grid |

## How a prompt becomes a manifest row

`src/generation/manifest.py` expands, for every prompt:

```
prompts x syntaxes (sd_native, comfyui, novelai) x levels (W1..W5)
```

giving `60 x 3 x 5 = 900` rows for `main` and the counts listed in
`data/README.md` overall. Each row records

* `prompt` — the plain text that is actually tokenised;
* `syntax_string` — just the weighted token, e.g. `(fox:2.0)` or `{{fox}}`;
* `rendered_prompt` — the full prompt with the syntax applied in place;
* `factor` — the numeric multiplier from `configs/weight_mapping.yaml`;
* `concept_key` — `experiment__prompt_id__seed`, the stable identity used to pair
  the W1 and W5 images for the DINOv2 distance;
* `seed`, `cfg_scale`, `steps`, `width`, `height`, `model`.

## Adding prompts

Append an entry with a fresh `id`, then rebuild the manifests:

```bash
python -m src.generation.generate_diffusers --dry-run --check
```

`--check` verifies the totals against the paper and fails loudly if a prompt
list changes the expected counts.
